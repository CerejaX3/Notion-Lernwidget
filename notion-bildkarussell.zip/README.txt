NOTION-BILDKARUSSELL

1. Lege in deinem bestehenden GitHub-Repository einen Ordner namens "carousel" an.
2. Lade index.html und den Ordner images in diesen Ordner hoch.
3. Die Adresse lautet danach:
   https://DEINNAME.github.io/DEIN-REPOSITORY/carousel/
4. Diese URL in Notion mit /Einbetten einfügen.

Das Widget:
- startet jeden Kalendertag automatisch mit einem anderen Bild,
- hat Pfeile zum Vor- und Zurückblättern,
- unterstützt Wischen auf Handy/Tablet.
